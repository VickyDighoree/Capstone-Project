
DataSet

Dataset Understanding: The dataset contains transactions made by credit card in Sept,2013 by European cardholders.This dataset presents transactions that occured in two days,where we have 492 frauds out of 284,807 transactions. The dataset is highly unbalanced, the positive class(frauds) accounts for 0.172% of all transactions.



